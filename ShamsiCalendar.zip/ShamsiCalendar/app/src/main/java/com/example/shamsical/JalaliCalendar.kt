package com.example.shamsical

import java.time.LocalDate

/** تاریخ شمسی (جلالی) */
data class JalaliDate(val year: Int, val month: Int, val day: Int) {

    fun toGregorian(): LocalDate {
        val (gy, gm, gd) = JalaliCalendar.jalaliToGregorian(year, month, day)
        return LocalDate.of(gy, gm, gd)
    }

    companion object {
        fun today(): JalaliDate = from(LocalDate.now())
        fun from(d: LocalDate): JalaliDate {
            val (jy, jm, jd) = JalaliCalendar.gregorianToJalali(d.year, d.monthValue, d.dayOfMonth)
            return JalaliDate(jy, jm, jd)
        }
    }
}

object JalaliCalendar {

    val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    /** هفته از شنبه شروع می‌شود */
    val weekDays = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
    val weekDaysShort = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return Triple(jy, jm, jd)
    }

    fun jalaliToGregorian(jyIn: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy = jyIn + 1595
        var days = -355668 + 365 * jy + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd +
            if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days--
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val sal = intArrayOf(
            0, 31, if ((gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0) 29 else 28,
            31, 30, 31, 30, 31, 31, 30, 31, 30, 31
        )
        var gm = 0
        while (gm < 13 && gd > sal[gm]) {
            gd -= sal[gm]; gm++
        }
        return Triple(gy, gm, gd)
    }

    fun monthLength(year: Int, month: Int): Int = when {
        month <= 6 -> 31
        month <= 11 -> 30
        else -> if (JalaliDate(year, 12, 30).let { JalaliDate.from(it.toGregorian()) == it }) 30 else 29
    }

    /** تعداد خانه‌های خالی قبل از روز اول ماه (شنبه = ۰) */
    fun firstDayOffset(year: Int, month: Int): Int {
        val dow = JalaliDate(year, month, 1).toGregorian().dayOfWeek.value // Mon=1..Sun=7
        return (dow + 1) % 7
    }

    fun weekDayName(d: JalaliDate): String {
        val dow = d.toGregorian().dayOfWeek.value
        return weekDays[(dow + 1) % 7]
    }

    fun toPersianDigits(n: Int): String = n.toString().map { '۰' + (it - '0') }.joinToString("")
}
