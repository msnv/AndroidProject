package com.example.shamsical

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/* ---------- فصل‌ها و رنگ‌ها ---------- */

enum class Season(val top: Color, val bottom: Color, val accent: Color, val particle: Color) {
    Spring(Color(0xFF134E4A), Color(0xFF22C55E), Color(0xFFFBCFE8), Color(0xFFFFC1E3)),
    Summer(Color(0xFF9A3412), Color(0xFFF59E0B), Color(0xFFFEF08A), Color(0xFFFFF3B0)),
    Autumn(Color(0xFF7C2D12), Color(0xFFEA580C), Color(0xFFFDBA74), Color(0xFFFFB066)),
    Winter(Color(0xFF0F172A), Color(0xFF1D4ED8), Color(0xFFBAE6FD), Color(0xFFFFFFFF));

    companion object {
        fun of(month: Int) = when (month) {
            in 1..3 -> Spring
            in 4..6 -> Summer
            in 7..9 -> Autumn
            else -> Winter
        }
    }
}

private fun Int.fa() = JalaliCalendar.toPersianDigits(this)

/* ---------- صفحه اصلی ---------- */

@Composable
fun CalendarScreen() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val today = remember { JalaliDate.today() }
        val initialPage = 1200
        val baseIndex = today.year * 12 + (today.month - 1)
        val pagerState = rememberPagerState(initialPage = initialPage) { 2400 }
        val scope = rememberCoroutineScope()
        var selected by remember { mutableStateOf(today) }

        fun monthOf(page: Int): Pair<Int, Int> {
            val idx = baseIndex + (page - initialPage)
            return idx / 12 to idx % 12 + 1
        }

        val (year, month) = monthOf(pagerState.currentPage)
        val season = Season.of(month)
        val top by animateColorAsState(season.top, tween(1000), label = "top")
        val bottom by animateColorAsState(season.bottom, tween(1000), label = "bottom")
        val accent by animateColorAsState(season.accent, tween(1000), label = "accent")
        val particle by animateColorAsState(season.particle, tween(1000), label = "particle")

        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(top, bottom)))
        ) {
            FloatingParticles(color = particle, falling = season != Season.Summer)

            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Header(
                    year = year,
                    month = month,
                    onPrev = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) } },
                    onNext = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) } },
                    onToday = {
                        selected = today
                        scope.launch { pagerState.animateScrollToPage(initialPage) }
                    }
                )

                Spacer(Modifier.height(16.dp))

                GlassCard(Modifier.weight(1f, fill = false)) {
                    Column(Modifier.padding(horizontal = 10.dp, vertical = 14.dp)) {
                        WeekDaysRow()
                        Spacer(Modifier.height(6.dp))
                        HorizontalPager(
                            state = pagerState,
                            modifier = Modifier.fillMaxWidth(),
                            beyondViewportPageCount = 1
                        ) { page ->
                            val (y, m) = monthOf(page)
                            val pageOffset = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                            val density = LocalDensity.current.density
                            Box(
                                Modifier.graphicsLayer {
                                    val o = abs(pageOffset).coerceAtMost(1f)
                                    alpha = 1f - o * 0.7f
                                    scaleX = 1f - 0.12f * o
                                    scaleY = 1f - 0.12f * o
                                    rotationY = pageOffset * -22f
                                    cameraDistance = 14f * density
                                }
                            ) {
                                MonthGrid(
                                    year = y, month = m, today = today, selected = selected,
                                    accent = accent, onSelect = { selected = it }
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                SelectedDayCard(selected, accent)
            }
        }
    }
}

/* ---------- سربرگ ---------- */

@Composable
private fun Header(year: Int, month: Int, onPrev: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RoundButton("›", onPrev)
        Spacer(Modifier.weight(1f))
        AnimatedContent(
            targetState = year to month,
            transitionSpec = {
                (slideInVertically { it / 2 } + fadeIn(tween(350))) togetherWith
                    (slideOutVertically { -it / 2 } + fadeOut(tween(250)))
            },
            label = "title"
        ) { (y, m) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(JalaliCalendar.monthNames[m - 1], color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(y.fa(), color = Color.White.copy(alpha = 0.75f), fontSize = 18.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        RoundButton("‹", onNext)
    }
    Spacer(Modifier.height(10.dp))
    Box(
        Modifier
            .align(Alignment.CenterHorizontally)
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onToday)
            .padding(horizontal = 18.dp, vertical = 8.dp)
    ) { Text("برو به امروز", color = Color.White, fontSize = 14.sp) }
}

@Composable
private fun RoundButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 26.sp) }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(28.dp))
    ) { content() }
}

@Composable
private fun WeekDaysRow() {
    Row(Modifier.fillMaxWidth()) {
        JalaliCalendar.weekDaysShort.forEachIndexed { i, d ->
            Text(
                d, modifier = Modifier.weight(1f), textAlign = TextAlign.Center,
                color = if (i == 6) Color(0xFFFFB4B4) else Color.White.copy(alpha = 0.8f),
                fontWeight = FontWeight.SemiBold, fontSize = 15.sp
            )
        }
    }
}

/* ---------- شبکه ماه ---------- */

@Composable
private fun MonthGrid(
    year: Int, month: Int, today: JalaliDate, selected: JalaliDate,
    accent: Color, onSelect: (JalaliDate) -> Unit
) {
    val offset = remember(year, month) { JalaliCalendar.firstDayOffset(year, month) }
    val length = remember(year, month) { JalaliCalendar.monthLength(year, month) }
    var shown by remember(year, month) { mutableStateOf(false) }
    LaunchedEffect(year, month) { shown = true }

    Column(Modifier.fillMaxWidth()) {
        for (row in 0 until 6) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val cellIndex = row * 7 + col
                    val day = cellIndex - offset + 1
                    Box(Modifier.weight(1f).aspectRatio(1f), contentAlignment = Alignment.Center) {
                        if (day in 1..length) {
                            val date = JalaliDate(year, month, day)
                            val appear by animateFloatAsState(
                                if (shown) 1f else 0f,
                                tween(450, delayMillis = cellIndex * 14, easing = FastOutSlowInEasing),
                                label = "appear"
                            )
                            DayCell(
                                day = day, isFriday = col == 6,
                                isToday = date == today, isSelected = date == selected,
                                accent = accent, onClick = { onSelect(date) },
                                modifier = Modifier.scale(0.6f + 0.4f * appear).alpha(appear)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    day: Int, isFriday: Boolean, isToday: Boolean, isSelected: Boolean,
    accent: Color, onClick: () -> Unit, modifier: Modifier = Modifier
) {
    val pop by animateFloatAsState(
        if (isSelected) 1.1f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow), label = "pop"
    )
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        0.25f, 0.9f,
        infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow"
    )

    Box(
        modifier
            .fillMaxSize(0.84f)
            .scale(pop)
            .clip(CircleShape)
            .then(if (isSelected) Modifier.background(Brush.linearGradient(listOf(accent, Color.White))) else Modifier)
            .then(if (isToday) Modifier.border(2.dp, accent.copy(alpha = glow), CircleShape) else Modifier)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            day.fa(),
            fontSize = 17.sp,
            fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.Normal,
            color = when {
                isSelected -> Color(0xFF1F2937)
                isFriday -> Color(0xFFFFB4B4)
                else -> Color.White
            }
        )
    }
}

/* ---------- کارت روز انتخاب‌شده ---------- */

@Composable
private fun SelectedDayCard(date: JalaliDate, accent: Color) {
    GlassCard {
        AnimatedContent(
            targetState = date,
            transitionSpec = { (fadeIn(tween(300)) + slideInVertically { it / 3 }) togetherWith fadeOut(tween(200)) },
            label = "selected"
        ) { d ->
            val g = d.toGregorian()
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(64.dp).clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(accent, Color.White))),
                    contentAlignment = Alignment.Center
                ) { Text(d.day.fa(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937)) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(
                        "${JalaliCalendar.weekDayName(d)}، ${d.day.fa()} ${JalaliCalendar.monthNames[d.month - 1]} ${d.year.fa()}",
                        color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        g.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)),
                        color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp
                    )
                }
            }
        }
    }
}

/* ---------- ذرات شناور (گلبرگ، برف، برگ، جرقه) ---------- */

private class Particle(val x: Float, val y: Float, val speed: Float, val size: Float, val phase: Float)

@Composable
private fun FloatingParticles(color: Color, falling: Boolean) {
    val particles = remember {
        val r = Random(7)
        List(36) { Particle(r.nextFloat(), r.nextFloat(), 0.4f + r.nextFloat(), 3f + r.nextFloat() * 7f, r.nextFloat() * 6.28f) }
    }
    val t by rememberInfiniteTransition(label = "particles").animateFloat(
        0f, 1f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        particles.forEach { p ->
            val progress = (p.y + t * p.speed) % 1f
            val yy = if (falling) progress else 1f - progress
            val xx = p.x + 0.03f * sin(t * 6.28f * 2f * p.speed + p.phase)
            val twinkle = if (falling) 0.55f else 0.3f + 0.5f * abs(sin(t * 6.28f * 3f + p.phase))
            drawCircle(
                color = color.copy(alpha = twinkle),
                radius = p.size.dp.toPx(),
                center = Offset(xx * size.width, yy * size.height)
            )
        }
    }
}
